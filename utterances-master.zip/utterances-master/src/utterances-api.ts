// export const UTTERANCES_API = 'http://localhost:7000';
export const UTTERANCES_API = 'https://api.utteranc.es';
