export default /^([\w-_]+)\/([\w-_.]+)$/i;
